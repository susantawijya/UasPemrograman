</main>

    <footer class="site-footer">
        <p>&copy; <?php echo date('Y'); ?> Gede Susanta Wijaya (322410006). All Rights Reserved.</p>
    </footer>

</div> </body>
</html>